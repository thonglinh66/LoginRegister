<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->yieldContent('title'); ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=DM+Serif+Display:400,400i|Roboto+Mono&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>">


  <link rel="stylesheet" href="<?php echo e(asset('fonts/ionicons/css/ionicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome/css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/flaticon/font/flaticon.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/aos.css')); ?>">
  <link rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/custom-bs.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/fonts/icomoon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/fonts/line-icons/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/Business_Home_View.css')); ?>">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/style.css')); ?>">   
   <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">

  <!-- Theme Style -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head>


<body>

<?php echo $__env->make('layouts/user/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- END header -->

   <?php echo $__env->yieldContent('content_head'); ?>

   <div class="section portfolio-section"  style=" height:10px; margin: 0px; display:block;">
    <div class="container"style="height: 0px;">
      <div class="row mb-5 justify-content-center" data-aos="fade-up">
        <div class="col-md-8 text-center">
          <h2 class="mb-4 section-title">History</h2>
          <p>Store user response history.</p>
        </div>
      </div>
    </div>
  </div>

  <!-- content body -->
  <section class="site-section" id="post">
  <div class="container">
  <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2">There are <?php echo e(count($report)); ?>  requirements in history </h2>
          </div>
        </div>
<ul class="job-listings mb-5">
    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="job-listing d-block d-sm-flex pb-3 pb-sm-0 align-items-center " >
        <a href="<?php echo e(route('home.detail', $r->id )); ?>"style="position: absolute;width: 100%;height: 100%;"></a>
        <div class="job-listing-logo">
            <img src="<?php echo e(asset('File/File_img/'.$r->image)); ?>"  style="width:200px; height=200px;" alt="Free Website Template by Free-Template.co" class="img-fluid">
        </div>

        <div class="job-listing-about d-sm-flex custom-width w-100 justify-content-between mx-4">
            <div class="job-listing-position custom-width w-50 mb-3 mb-sm-0">
            <h2><?php echo e($r->title); ?>	&nbsp;	&nbsp;	&nbsp;(<?php echo e($r->createreport); ?>)</h2>
            <strong><?php echo e($r->description); ?></strong>
            </div>
            <div class="job-listing-location mb-3 mb-sm-0 custom-width w-25">
            <span class="icon-room"></span> <?php echo e($r->address); ?>

            </div>
            <div class="job-listing-meta">

            <span class="badge badge-danger">
            <?php if($r->status == 0): ?>
              Posted
            <?php endif; ?>
            <?php if($r->status == 1): ?>
              Approved
            <?php endif; ?>
            <?php if($r->status == 2): ?>
            Processing
            <?php endif; ?>
            <?php if($r->status == 3): ?>
              Fixed
            <?php endif; ?>
            </span>
            </div>
        </div>
            
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="row pagination-wrap">
          
      <div class="col-md-6 text-center text-md-left mb-4 mb-md-0">
 
      </div>
      <div class="col-md-6 text-center text-md-right">
      <?php echo e($report->links()); ?>

          </div>
    </div>
    </div>
    </div>
    </section>

  <!-- END .block-4 -->

  
  <?php echo $__env->make('layouts/user/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts/user/js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\LoginRegister\resources\views/layouts/history.blade.php ENDPATH**/ ?>