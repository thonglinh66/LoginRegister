

<?php $__env->startSection('title'); ?>
    <title>HelpDesk</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active'); ?>
    <li class="nav-item">
        <a class="nav-link active" href="<?php echo e(route('home.index', $user)); ?>">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="about.html">Report</a>
    </li>
    
    <li class="nav-item">
        <a class="nav-link" href="portfolio.html">Projects</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="contact.html">Contact</a>
    </li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_head'); ?>
<div class="slider-item overlay" data-stellar-background-ratio="0.5"
    style="background-image: url(<?php echo e(asset('images/hero_2.jpg')); ?>);">
    <div class="container">
      <div class="row slider-text align-items-center justify-content-center">
        <div class="col-lg-12 text-center col-sm-12">
          <h1 class="mb-4" data-aos="fade-up" data-aos-delay="100">HelpDesk </h1>
          <p data-aos="fade-up" data-aos="fade-up" data-aos-delay="">A website by Tăng Minh Thông_B1704774 and Huỳnh Nhựt Huy_B1704812</p>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LoginRegister\resources\views/pages/home.blade.php ENDPATH**/ ?>