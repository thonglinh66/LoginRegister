

<?php $__env->startSection('title'); ?>
    <title>HelpDesk</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active'); ?>
    <li class="nav-item">
        <a class="nav-link active" href="<?php echo e(route('technicians.index')); ?>">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('technicians.work')); ?>">Work</a>
    </li>
    <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('technicians.history')); ?>">History</a>
    </li>
    <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('technicians.edit')); ?>">Edit account</a>
    </li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_head'); ?>
<div class="slider-item overlay" data-stellar-background-ratio="0.5"
    style="background-image: url(<?php echo e(asset('images/hero_2.jpg')); ?>);">
    <div class="container">
      <div class="row slider-text align-items-center justify-content-center">
        <div class="col-lg-12 text-center col-sm-12">
          <h1 class="mb-4" data-aos="fade-up" data-aos-delay="100">HelpDesk </h1>
          <p data-aos="fade-up" data-aos="fade-up" data-aos-delay="">A website design by Tăng Minh Thông_B1704774 and Huỳnh Nhựt Huy_B1704812</p>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.technicians', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LoginRegister\resources\views/pages/tech/technicians.blade.php ENDPATH**/ ?>