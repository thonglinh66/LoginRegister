<head>
<?php echo $__env->yieldContent('title'); ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=DM+Serif+Display:400,400i|Roboto+Mono&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>">


  <link rel="stylesheet" href="<?php echo e(asset('fonts/ionicons/css/ionicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome/css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/flaticon/font/flaticon.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/aos.css')); ?>">
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">

  <!-- Theme Style -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head>
<?php /**PATH C:\xampp\htdocs\LoginRegister\resources\views/layouts/user/head.blade.php ENDPATH**/ ?>