<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="<?php echo e(asset('UserView/css/favicon.ico')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
<!--===============================================================================================-->
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/fonts/iconic/css/material-design-iconic-font.min.css')); ?>">
<!--===============================================================================================-->

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/vendor/animate/animate.css')); ?>">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/vendor/css-hamburgers/hamburgers.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/vendor/animsition/css/animsition.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/vendor/select2/select2.min.css')); ?>">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/vendor/daterangepicker/daterangepicker.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/css/util.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/css/main.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('UserView/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<!--===============================================================================================-->
	
</head><?php /**PATH C:\xampp\htdocs\LoginRegister\resources\views/layouts/user/head_login.blade.php ENDPATH**/ ?>