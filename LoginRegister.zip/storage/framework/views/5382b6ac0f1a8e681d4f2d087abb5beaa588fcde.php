

<?php $__env->startSection('command'); ?>
  <?php if(Session::has('name')): ?>
<script>
      var msg = '<?php echo e(Session::get('name')); ?>';
        alert(msg);
  </script>
      <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <title>Report</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active'); ?>
    <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('home.index')); ?>">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link active" href="<?php echo e(route('home.report')); ?>">Report</a>
    </li>
    
    <li class="nav-item">
      <a class="nav-link " href="<?php echo e(route('home.history')); ?>">History</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('home.edit')); ?>">Edit account</a>
    </li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_head'); ?>
<div class="slider-item overlay" data-stellar-background-ratio="0.5"
    style="background-image: url(<?php echo e(asset('images/hero_2.jpg')); ?>);">
    <div class="container">
      <div class="row slider-text align-items-center justify-content-center">
        <div class="col-lg-12 text-center col-sm-12">
        <h1 class="mb-4" data-aos="fade-up" data-aos-delay="">Report</h1>
          <p class="custom-breadcrumbs" data-aos="fade-up" data-aos-delay="100"><a href="<?php echo e(route('home.index')); ?>">Home</a> <span class="mx-3">/</span> Report</p>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LoginRegister\resources\views/pages/users/report.blade.php ENDPATH**/ ?>