<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->yieldContent('title'); ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=DM+Serif+Display:400,400i|Roboto+Mono&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>">


  <link rel="stylesheet" href="<?php echo e(asset('fonts/ionicons/css/ionicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/fontawesome/css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/flaticon/font/flaticon.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/aos.css')); ?>">
  <link rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/custom-bs.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/fonts/icomoon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/fonts/line-icons/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/Business_Home_View.css')); ?>">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('cssjobs/css/style.css')); ?>">   
   <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">

  <!-- Theme Style -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head>
<body>

<?php echo $__env->make('layouts/user/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- END header -->

   <?php echo $__env->yieldContent('content_head'); ?>

   <div class="section portfolio-section"  style=" height:10px; margin: 0px; display:block;">
    <div class="container"style="height: 0px;">
      <div class="row mb-5 justify-content-center" data-aos="fade-up">
        <div class="col-md-8 text-center">
          <h2 class="mb-4 section-title">Delail</h2>
          <p>Show details of a request in history.</p>
        </div>
      </div>
    </div>
  </div>

  <!-- content body -->        
    <section class="site-section" style="border-top: 1px solid; width: 100%;">
      <div class="container">
        <div class="row align-items-center mb-5">
          <div class="col-lg-8 mb-4 mb-lg-0" style="margin:0 auto;">
            <div class="d-flex align-items-center">
            <a href="#" class="border p-2 d-inline-block mr-3 rounded">

              <img src="<?php echo e(asset('File/File_img/'. $report->image)); ?>"style="width:100px; height:100px;" alt="Image">
              </a>
              <div>
                <h2><?php echo e($report->title); ?></h2>
                <div>
                  <span class="ml-0 mr-2 mb-2"><span class="icon-briefcase mr-2"></span><?php echo e($report->address); ?></span>
                  
                  <?php if($report->status == 0): ?>
                     <span class="m-2"><span class="icon-clock-o mr-2"></span><span class="text-primary">Posted</span></span>
                  <?php endif; ?>  
                  <?php if($report->status == 1): ?>
                     <span class="m-2"><span class="icon-clock-o mr-2"></span><span class="text-primary">Approved</span></span>
                  <?php endif; ?> 
                  <?php if($report->status == 2): ?>
                     <span class="m-2"><span class="icon-clock-o mr-2"></span><span class="text-primary">Processing</span></span>
                  <?php endif; ?>  
                  <?php if($report->status == 3): ?>
                     <span class="m-2"><span class="icon-clock-o mr-2"></span><span class="text-primary">Fixed</span></span>
                  <?php endif; ?>   
                  <!-- <span class="m-2"><span class="icon-room mr-2"></span><?php echo e($report->title); ?></span> -->
                </div>
                
              </div>
              
              
            </div>
          <div class="row" style="margin-top: 30px;">
          <div class="row" >
            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-book mr-3"></span>	Description</h3>
              <ul class="list-unstyled m-0 p-0">
              <li class="d-flex align-items-start mb-2"><span style="padding-top:7px;" class="icon-check_circle mr-2 text-muted"></span><span><?php echo e($report->description); ?></span></li>
                
            </div>

            <div class="mb-5">
              <h3 style="display: inline;" class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-turned_in mr-3"></span>Time &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h3>
              <ul class="list-unstyled m-0 p-0">
              <li class="d-flex align-items-start mb-2"><span style="padding-top:6px;" class="icon-check_circle mr-2 text-muted"></span><span>Createreport:&nbsp;&nbsp;<?php echo e($report->createreport); ?></span></li>
              <li class="d-flex align-items-start mb-2"><span style="padding-top:6px;" class="icon-check_circle mr-2 text-muted"></span><span>Solve:&nbsp;&nbsp;<?php echo e($report->solve); ?></span></li>
              <li class="d-flex align-items-start mb-2"><span style="padding-top:6px;" class="icon-check_circle mr-2 text-muted"></span><span>Completed:&nbsp;&nbsp;<?php echo e($report->completed); ?></span></li>
              </ul>
            </div>
            <div class="mb-5">
              <h3 style="display: inline;" class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-turned_in mr-3"></span>Employee</h3>
              <ul class="list-unstyled m-0 p-0">
              <li class="d-flex align-items-start mb-2"><span style="padding-top:6px;" class="icon-check_circle mr-2 text-muted"></span><span>Name:&nbsp;&nbsp;<?php echo e($employee->fullname); ?></span></li>
              <li class="d-flex align-items-start mb-2"><span style="padding-top:6px;" class="icon-check_circle mr-2 text-muted"></span><span>Chức vụ:&nbsp;&nbsp;<?php echo e($employee->position); ?></span></li>
              </ul>
            </div>
          </div>
          </div>

       
         
        
      </div>

          
        </div>
      </div>
    </section>

  <!-- END .block-4 -->

  
  <?php echo $__env->make('layouts/user/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts/user/js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\LoginRegister\resources\views/layouts/tech_detail.blade.php ENDPATH**/ ?>