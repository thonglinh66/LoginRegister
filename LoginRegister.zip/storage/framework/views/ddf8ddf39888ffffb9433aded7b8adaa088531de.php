<!--===============================================================================================-->
<script src="<?php echo e(asset('UserView/js/jquery-3.2.1.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('UserView/js/animsition.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('UserView/js/popper.js')); ?>"></script>
	<script src="<?php echo e(asset('UserView/js/bootstrap.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('UserView/js/select2.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('UserView/js/moment.min.js')); ?>"></script>
	<script src="<?php echo e(asset('UserView/js/daterangepicker.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('UserView/js/countdowntime.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('UserView/js/main.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\LoginRegister\resources\views/layouts/user/js_login.blade.php ENDPATH**/ ?>